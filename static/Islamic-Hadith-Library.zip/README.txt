Nur-ul-Islam • Islamic & Hadith Library - Standalone Offline Web App
==================================================================
Features:
- Authentic Bukhari, Muslim, and Nawawi Collections
- 4-Language Support (Arabic, Hindi, Urdu, English)
- Authentic Arabic Recitation Audio & Audio Player
- Text-to-Speech Fallback
- Prayer Times & Qibla Direction
- Full Holy Quran Surah Browser

How to Run:
Double-click 'index.html' or 'Islamic-Hadith-Library.html' in any browser.
No installation or server required!
