Weather Experience (2026) - Standalone Offline Web App
======================================================
Features:
- RainViewer Zero-Key Doppler Radar Player
- Open-Meteo High-Resolution Synoptic Engine
- Real-time Air Quality (AQI) Gauge
- Real-time UV Index
- 7-Day Precision Forecast
- 100% Client-Side / Standalone

How to Run:
Double-click 'index.html' or 'Weather-Experience-2026.html' in any browser (Chrome, Firefox, Safari, Edge).
No installation or server required!
