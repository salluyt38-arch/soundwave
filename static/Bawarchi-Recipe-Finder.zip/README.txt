App: recipes.html
Owner: Sallu
SoundWave Services Suite 2026
Double click recipes.html in any browser (Chrome, Edge, Firefox, Safari) to run completely offline.